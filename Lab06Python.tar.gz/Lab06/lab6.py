from flask import Flask, render_template, request, jsonify
import json
import os

app = Flask(__name__)

    
#returns the student name
@app.route('/team')
def team():
    return '<h1>Group7: Hwayoung Choi </h1>'

#returns the contents of the file and display to a browser from json file   
@app.route('/data', methods=['Get'])
def readJson():
    if os.path.exists('customer.json'):
        with open('customer.json') as theFile:
            data = json.load(theFile)
        return render_template('customerTable.html', n=len(data), theData = data)
    else:
        return 'no json file'

#client sends a json, create file and update it
@app.route('/add', methods=['POST'])
def getJson():
    data = request.get_json() #get json
    with open("dummyData.json", "a+") as theFile:
        json.dump(data, theFile)
    return 'saved'
    
if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True)   
