package com.example.lab06client

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*

data class CustomerName(
    val first_name: String,
    val last_name: String
)

interface RetrofitServicce{

    @Headers("Content-type: application/json")
    @POST("/add")
    fun postRequest(@Body body: List<CustomerName>): Call<ResponseBody>

}