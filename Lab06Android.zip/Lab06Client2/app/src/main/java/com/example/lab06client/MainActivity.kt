package com.example.lab06client

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.JsonObject
import com.squareup.moshi.JsonAdapter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.ResponseBody
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.BufferedReader

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val baseUrl = this.assets.open("serverUrl.txt").use {
            it.bufferedReader().use {
                it.readText()
            }
        }

        val customerNameList = getJSON(this)

        //connect
        var retrofit = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retrofit.create(RetrofitServicce::class.java)

        //post json file to server
        service.postRequest(customerNameList).enqueue(object : Callback<ResponseBody>
            {
                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Log.i("post", "fail " + t.message.toString())
                    txtViewResult.setText("fail")
                }
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    Log.i("post",baseUrl + " connected and post success ")
                    txtViewResult.setText(baseUrl + " connected \nsend json file to server")
                }

            }
        )

    }

    fun getJSON(context : Context): List<CustomerName> {

        val jsonText = context.assets.open("customerName.json").use {
            it.bufferedReader().use { reader: BufferedReader ->
                reader.readText()
            }
        }
        val myType =
            Types.newParameterizedType(List::class.java, CustomerName::class.java)
        val moshi: Moshi = Moshi.Builder().build()
        val adapter: JsonAdapter<List<CustomerName>> = moshi.adapter(myType)
        val customerList = adapter.fromJson(jsonText)

        return customerList!!
    }

}